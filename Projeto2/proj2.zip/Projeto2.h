/* Caso este ficheiro, quando for chamado, nao estiver definido, define-o */

#ifndef Projeto2_H
#define Projeto2_H




/* Os headers necessarios estao declarados. */

#include "Tree.h"
#include "Item_lib.h"




/* Prototipos das funcoes associadas aos comandos do programa */

void init();
void executa_a();
void executa_l();
//void traverse_maxumis(link h, Item *j);
void executa_m();
void executa_r();
void apaga_arvore(link h);
void executa_x();




#endif